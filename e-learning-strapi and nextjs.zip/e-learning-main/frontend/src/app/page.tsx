import React from "react";
import Login from "../pages_dir/Login";

export default function Page() {
  return (
    <>
      <Login />
    </>
  );
}
