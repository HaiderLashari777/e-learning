import React from "react";
import Dashbaord from "../../pages_dir/Dashboard";

export default function Page() {
  return <Dashbaord />;
}
