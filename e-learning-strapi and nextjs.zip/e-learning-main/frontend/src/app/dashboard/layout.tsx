import React from "react";
import Sidebar from "../../components/common/Sidebar";

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <div>
      <div className="flex">
        <Sidebar />
        <div className="pl-[280px] py-8">{children}</div>
      </div>
    </div>
  );
}
