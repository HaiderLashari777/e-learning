import React from "react";
import Profile from "../../pages_dir/Profile";

export default function Page() {
  return <Profile />;
}
